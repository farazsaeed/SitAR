//
//  Track.swift
//  app
//
//  Created by Ahsan on 03/06/2020.
//  Copyright © 2020 Faraz saeed. All rights reserved.
//

import Foundation
struct Track{
    var trackId: Int
    var Targets: [Target]
}
