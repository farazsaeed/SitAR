//
//  TrackData.swift
//  app
//
//  Created by Ahsan on 03/06/2020.
//  Copyright © 2020 Faraz saeed. All rights reserved.
//

import Foundation


struct TrackData{
    var Tracks = [Track(trackId: 1, Targets: targets1),
                  Track(trackId: 2, Targets: targets2),
                  Track(trackId: 3, Targets: targets3),
                  Track(trackId: 4, Targets: targets4)
    ]
}
//Data for trackID = 1
let targets1: [Target] = [
    Target(latitude: 51.228032, longitude: -116.270501, heading: 0.785398, altitude: 3000.0),
    Target(latitude: 51.228032, longitude: -116.270501, heading: 0.785398, altitude: 3000.0),//Dup
    Target(latitude: 51.228032, longitude: -116.270501, heading: 0.785398, altitude: 3000.0),//Dup
    Target(latitude: 51.228032, longitude: -116.270501, heading: 0.785398, altitude: 3000.0),//Dup
    Target(latitude: 51.228032, longitude: -116.270501, heading: 0.785398, altitude: 3000.0),//Dup
    Target(latitude: 51.228032, longitude: -116.270501, heading: 0.785398, altitude: 3000.0),//Dup
    Target(latitude: 51.228032, longitude: -116.270501, heading: 0.785398, altitude: 3000.0),//Dup
    Target(latitude: 51.228032, longitude: -116.270501, heading: 0.785398, altitude: 3000.0),//Dup
    Target(latitude: 51.228032, longitude: -116.270501, heading: 0.785398, altitude: 3000.0),//Dup
    Target(latitude: 51.228032, longitude: -116.270501, heading: 0.785398, altitude: 3000.0),//Dup
    Target(latitude: 51.228032, longitude: -116.270501, heading: 0.785398, altitude: 3000.0),//Dup
    Target(latitude: 51.220937, longitude: -116.255051, heading: 2.1944, altitude: 3000.0),
    Target(latitude: 51.225667, longitude: -116.239258, heading: 2.1944, altitude: 3000.0),
    Target(latitude: 51.232117, longitude: -116.224839, heading: 2.1944, altitude: 3000.0),
    Target(latitude: 51.236202, longitude: -116.214882, heading: 2.1944, altitude: 3000.0),
    Target(latitude: 51.240071, longitude: -116.203553, heading: 2.1944, altitude: 3000.0),
    Target(latitude: 51.244799, longitude: -116.192223, heading: 2.1944, altitude: 3000.0),
    Target(latitude: 51.248023, longitude: -116.182610, heading: 2.1944, altitude: 3000.0),
    Target(latitude: 51.251670, longitude: -116.172310, heading: 2.1944, altitude: 3000.0),
    Target(latitude: 51.255544, longitude: -116.161667, heading: 2.1944, altitude: 3000.0),
    Target(latitude: 51.259841, longitude: -116.145531, heading: 2.1944, altitude: 3000.0)
]
let targets2: [Target] = [
    Target(latitude: 51.228032, longitude: -116.145531, heading: 4.10152, altitude: 3800.0),
    Target(latitude: 51.228032, longitude: -116.145531, heading: 4.10152, altitude: 3800.0),//Dup
    Target(latitude: 51.228032, longitude: -116.145531, heading: 4.10152, altitude: 3800.0),//Dup
    Target(latitude: 51.228032, longitude: -116.145531, heading: 4.10152, altitude: 3800.0),//Dup
    Target(latitude: 51.228032, longitude: -116.145531, heading: 4.10152, altitude: 3800.0),//Dup
    Target(latitude: 51.228032, longitude: -116.145531, heading: 4.10152, altitude: 3800.0),//Dup
    Target(latitude: 51.228032, longitude: -116.145531, heading: 4.10152, altitude: 3800.0),//Dup
    Target(latitude: 51.228032, longitude: -116.145531, heading: 4.10152, altitude: 3800.0),//Dup
    Target(latitude: 51.228032, longitude: -116.145531, heading: 4.10152, altitude: 3800.0),//Dup
    Target(latitude: 51.228032, longitude: -116.145531, heading: 4.10152, altitude: 3800.0),//Dup
    Target(latitude: 51.228032, longitude: -116.145531, heading: 4.10152, altitude: 3800.0),//Dup
    Target(latitude: 51.220937, longitude: -116.161667, heading: 4.10152, altitude: 3800.0),
    Target(latitude: 51.225667, longitude: -116.172310, heading: 4.10152, altitude: 3800.0),
    Target(latitude: 51.232117, longitude: -116.182610, heading: 4.10152, altitude: 3800.0),
    Target(latitude: 51.236202, longitude: -116.192223, heading: 4.10152, altitude: 3800.0),
    Target(latitude: 51.240071, longitude: -116.203553, heading: 4.10152, altitude: 3800.0),
    Target(latitude: 51.244799, longitude: -116.214882, heading: 4.10152, altitude: 3800.0),
    Target(latitude: 51.248023, longitude: -116.224839, heading: 4.10152, altitude: 3800.0),
    Target(latitude: 51.251670, longitude: -116.239258, heading: 4.10152, altitude: 3800.0),
    Target(latitude: 51.260670, longitude: -116.239258, heading: 3.14159, altitude: 3800.0),
    Target(latitude: 51.269670, longitude: -116.239258, heading: 3.14159, altitude: 3800.0),
    Target(latitude: 51.275670, longitude: -116.239258, heading: 3.14159, altitude: 3800.0),
    Target(latitude: 51.283670, longitude: -116.239258, heading: 3.14159, altitude: 3800.0),
    Target(latitude: 51.291670, longitude: -116.239258, heading: 3.14159, altitude: 3800.0),
    Target(latitude: 51.297670, longitude: -116.239258, heading: 3.14159, altitude: 3800.0),
    Target(latitude: 51.300670, longitude: -116.239258, heading: 3.14159, altitude: 3800.0),
    Target(latitude: 51.301370, longitude: -116.239258, heading: 3.14159, altitude: 3800.0)
    //Target(latitude: 51.255544, longitude: -116.255051, heading: 4.10152),
    //Target(latitude: 51.259841, longitude: -116.270501, heading: 4.10152)
]
let targets3: [Target] = [
    Target(latitude: 51.210344, longitude: -116.145531, heading: 4.71239, altitude: 3000.0),
    Target(latitude: 51.210344, longitude: -116.145531, heading: 4.71239, altitude: 3000.0),//Dup
    Target(latitude: 51.210344, longitude: -116.145531, heading: 4.71239, altitude: 3000.0),//Dup
    Target(latitude: 51.210344, longitude: -116.145531, heading: 4.71239, altitude: 3000.0),//Dup
    Target(latitude: 51.210344, longitude: -116.145531, heading: 4.71239, altitude: 3000.0),//Dup
    Target(latitude: 51.210344, longitude: -116.145531, heading: 4.71239, altitude: 3000.0),//Dup
    Target(latitude: 51.210344, longitude: -116.145531, heading: 4.71239, altitude: 3000.0),//Dup
    Target(latitude: 51.210344, longitude: -116.145531, heading: 4.71239, altitude: 3000.0),//Dup
    Target(latitude: 51.210344, longitude: -116.145531, heading: 4.71239, altitude: 3000.0),//Dup
    Target(latitude: 51.210344, longitude: -116.145531, heading: 4.71239, altitude: 3000.0),//Dup
    Target(latitude: 51.210344, longitude: -116.145531, heading: 4.71239, altitude: 3000.0),//Dup
    Target(latitude: 51.210344, longitude: -116.154431, heading: 4.71239, altitude: 3000.0),
    Target(latitude: 51.210344, longitude: -116.165531, heading: 4.71239, altitude: 3000.0),
    Target(latitude: 51.210344, longitude: -116.175531, heading: 4.71239, altitude: 3000.0),
    Target(latitude: 51.210344, longitude: -116.179531, heading: 4.71239, altitude: 3000.0),
    Target(latitude: 51.210344, longitude: -116.185513, heading: 4.71239, altitude: 3000.0),
    Target(latitude: 51.210344, longitude: -116.195513, heading: 4.71239, altitude: 3000.0),
    Target(latitude: 51.210344, longitude: -116.205513, heading: 4.71239, altitude: 3000.0),
    Target(latitude: 51.210344, longitude: -116.215513, heading: 4.71239, altitude: 3000.0),
    Target(latitude: 51.210344, longitude: -116.225513, heading: 4.71239, altitude: 3000.0),
    Target(latitude: 51.210344, longitude: -116.245513, heading: 4.71239, altitude: 3000.0),
    Target(latitude: 51.210344, longitude: -116.249913, heading: 4.71239, altitude: 3000.0),
    Target(latitude: 51.210344, longitude: -116.255513, heading: 4.71239, altitude: 3000.0),
    Target(latitude: 51.210344, longitude: -116.266613, heading: 4.71239, altitude: 3000.0)
]
let targets4: [Target] = [
    Target(latitude: 51.232818, longitude: -116.178755, heading: 4.10152, altitude: 200),
    Target(latitude: 51.232818, longitude: -116.178755, heading: 4.10152, altitude: 200),//Dup
    Target(latitude: 51.232818, longitude: -116.178755, heading: 4.10152, altitude: 200),//Dup
    Target(latitude: 51.232818, longitude: -116.178755, heading: 4.10152, altitude: 200),//Dup
    Target(latitude: 51.232818, longitude: -116.178755, heading: 4.10152, altitude: 200),//Dup
    Target(latitude: 51.232818, longitude: -116.178755, heading: 4.10152, altitude: 200),//Dup
    Target(latitude: 51.232818, longitude: -116.178755, heading: 4.10152, altitude: 200),//Dup
    Target(latitude: 51.232818, longitude: -116.178755, heading: 4.10152, altitude: 200),//Dup
    Target(latitude: 51.232818, longitude: -116.178755, heading: 4.10152, altitude: 200),//Dup
    Target(latitude: 51.232818, longitude: -116.178755, heading: 4.10152, altitude: 200),//Dup
    Target(latitude: 51.232818, longitude: -116.178755, heading: 4.10152, altitude: 200),//Dup
    Target(latitude: 51.237009, longitude: -116.183905, heading: 4.10152, altitude: 200),
    Target(latitude: 51.239696, longitude: -116.188830, heading: 4.10152, altitude: 200),
    Target(latitude: 51.243135, longitude: -116.194377, heading: 4.10152, altitude: 200),
    Target(latitude: 51.245075, longitude: -116.197870, heading: 4.10152, altitude: 200),
    Target(latitude: 51.247005, longitude: -116.200500, heading: 4.10152, altitude: 200),
    Target(latitude: 51.248005, longitude: -116.204500, heading: 4.10152, altitude: 200),
    Target(latitude: 51.250205, longitude: -116.212000, heading: 4.10152, altitude: 300)
]
