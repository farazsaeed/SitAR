//
//  ViewController.swift
//  app
//
//  Created by Faraz saeed on 10/05/2020.
//  Copyright © 2020 Faraz saeed. All rights reserved.
//

import UIKit
import Mapbox
import MapboxSceneKit
import MapKit
import SceneKit
import ARKit
class ViewController: UIViewController,ARSCNViewDelegate {
    
    
    @IBOutlet weak var sceneView: ARSCNView!
    var minLat = 51.20
    var minLon = -116.28
    var maxLat = 51.32
    var maxLon =   -116.12
    var terrainNode: TerrainNode?
    var terrainNodeScale = SCNVector3(0.00003, 0.00003, 0.00003) // Scale down map (otherwise it's far too big)
    
    var trackpoints:[CLLocationCoordinate2D]?
    var trackData = TrackData()
    let cameraNode = SCNNode()
    var trackColors = [#colorLiteral(red: 0.9372549057, green: 0.3490196168, blue: 0.1921568662, alpha: 1),#colorLiteral(red: 0.3647058904, green: 0.06666667014, blue: 0.9686274529, alpha: 1),#colorLiteral(red: 0.9607843161, green: 0.7058823705, blue: 0.200000003, alpha: 1),#colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1),#colorLiteral(red: 0.9568627477, green: 0.6588235497, blue: 0.5450980663, alpha: 1),#colorLiteral(red: 0.2745098174, green: 0.4862745106, blue: 0.1411764771, alpha: 1)]//to be adjusted with tracks
    var nodeDescription = [String]()
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        // Create a session configuration
        let configuration = ARWorldTrackingConfiguration()
        
        configuration.planeDetection = .horizontal
        
        // Run the view's session
        sceneView.session.run(configuration)
    }
    
    func createTerrain() {
        terrainNode = TerrainNode(minLat: minLat, maxLat: maxLat,
                                  minLon: minLon, maxLon: maxLon)
        if let terrainNode = terrainNode {
            terrainNode.scale = terrainNodeScale // Scale down map
            terrainNode.geometry?.materials = defaultMaterials()
            terrainNode.position=SCNVector3(0, 0, -1)
            sceneView.scene.rootNode.addChildNode(terrainNode)
            
            //create terrain geometry based on mapbox elevation data
            
            terrainNode.fetchTerrainAndTexture(minWallHeight: 50.0, enableDynamicShadows: true, textureStyle: "mapbox/satellite-v9", heightProgress: nil, heightCompletion: { fetchError in
                if let fetchError = fetchError {
                    NSLog("Terrain load failed: \(fetchError.localizedDescription)")
                } else {
                    NSLog("Terrain load complete")
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.0){//thread
                        self.addDataToTerrain()
                    }
                    
                }
            }, textureProgress: nil) { image, fetchError in
                if let fetchError = fetchError {
                    NSLog("Texture load failed: \(fetchError.localizedDescription)")
                }
                if image != nil {
                    NSLog("Texture load complete")
                    terrainNode.geometry?.materials[4].diffuse.contents = image
                }
            }
            
            
            print("Ended CreateTerrain..")
            // self.addValleyofTheTenPeaksPOIMarkers()
        }
    }
    func defaultMaterials() -> [SCNMaterial] {
        let groundImage = SCNMaterial()
        groundImage.diffuse.contents = UIColor.darkGray
        groundImage.name = "Ground texture"
        
        let sideMaterial = SCNMaterial()
        sideMaterial.diffuse.contents = UIColor.darkGray
        sideMaterial.isDoubleSided = true
        sideMaterial.name = "Side"
        
        let bottomMaterial = SCNMaterial()
        bottomMaterial.diffuse.contents = UIColor.black
        bottomMaterial.name = "Bottom"
        
        return [sideMaterial, sideMaterial, sideMaterial, sideMaterial, groundImage, bottomMaterial]
    }
    
    
    
    func addDataToTerrain() {
        var targetIndex = 0
        var timeLapse = 0
        
        if let terrainNode = terrainNode{
            while targetIndex >= 0{
                if trackData.Tracks.count == 0{
                    targetIndex = -2 //break the while loop
                }
                var trackIndex = 0
                var trackCount = trackData.Tracks.count // to allow multiple targets to appear
                for track in trackData.Tracks{
                    if track.Targets.count > targetIndex {
                        //Display the node
                        let nodeDesc = "Id: "+String(track.trackId)+"\n"+"Lat: "+String(track.Targets[targetIndex].latitude)+"\n"+"Long: "+String(track.Targets[targetIndex].longitude)+"\n"+"Alt: "+String(track.Targets[targetIndex].altitude)+"\n"+"Heading: "+String(track.Targets[targetIndex].heading)
                        nodeDescription.append(nodeDesc)
                        let targetLocation = CLLocation(latitude: track.Targets[targetIndex].latitude, longitude: track.Targets[targetIndex].longitude)
                        var objectScene = SCNScene()
                        var objectNode = SCNNode()
                        if track.trackId == 4 {//land moving
                            objectScene = SCNScene(named: "art.scnassets/Car.dae")!
                            objectNode = objectScene.rootNode.childNode(withName: "Car", recursively: true)!
                            objectNode.scale = SCNVector3(x: 120, y: 120, z: 120)//changes value in handletap
                        }
                        else{
                            objectScene = SCNScene(named: "art.scnassets/ship.scn")!
                            objectNode = objectScene.rootNode.childNode(withName: "ship", recursively: true)!
                            objectNode = objectNode.childNodes[0]
                            objectNode.childNodes[0].removeFromParentNode()
                            objectNode.scale = SCNVector3(x: 20, y: 20, z: 20)//changes value in handletap
                            
                        }
                        
                        
                        objectNode.position = terrainNode.positionForLocation(targetLocation)
                        objectNode.position.y = track.Targets[targetIndex].altitude
                        
                        objectNode.rotation = SCNVector4(0, 1, 0, track.Targets[targetIndex].heading)
                        let trackCountToQueue = trackCount
                        var historyColor = UIColor(named: "red")//default color
                        if track.trackId<trackColors.count{
                            historyColor = trackColors[track.trackId]
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + Double(timeLapse)){
                            print("In dispatch queue")
                            
                            if terrainNode.childNodes.count >= trackCountToQueue {
                                //print("Index is: ")
                                //print(terrainNode.childNodes.count-trackCountToQueue)
                                let prevNode =  terrainNode.childNodes[terrainNode.childNodes.count-trackCountToQueue]
                                let box = SCNBox(width: 0.25, height: 0.25, length: 0.25, chamferRadius: 0.25)
                                box.firstMaterial?.diffuse.contents  = historyColor
                                let boxNode = SCNNode(geometry: box)
                                boxNode.position = prevNode.position
                                if boxNode.position.y < 500.0{//for land moving vehicles
                                    boxNode.scale = SCNVector3(x: 800, y: 800, z: 800)
                                }else{
                                    boxNode.scale = SCNVector3(x: 1200, y: 1200, z: 1200)
                                }
                                terrainNode.replaceChildNode(prevNode, with: boxNode)
                                
                            }
                            terrainNode.addChildNode(objectNode)
                        }
                        
                    }
                    else{
                        //End of track
                        trackData.Tracks.remove(at:  trackIndex)
                        trackCount -= 1
                        trackIndex -= 1
                    }
                    trackIndex+=1
                }
                targetIndex+=1
                timeLapse+=1
            }
            
            
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        sceneView.delegate = self
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        sceneView.addGestureRecognizer(tapGestureRecognizer)
        createTerrain()
        //  setupSceneView()
        print("viewDidLoadCalled..")
        
        
    }
    func removeTextNodes(){
        if let terrainNode = terrainNode{
            for node in terrainNode.childNodes{
                while let n = node.childNodes.first {
                    n.removeFromParentNode()
                }
            }
        }
    }
    @objc func handleTap(sender:UITapGestureRecognizer) // this function handles the touch gestures
    {
        let sceneViewTappedOn=sender.view as! ARSCNView
        let touchedCordinates = sender.location(in: sceneViewTappedOn)
        let hitTest = sceneViewTappedOn.hitTest(touchedCordinates)
        
        if hitTest.isEmpty{
            print("didn't touch")
            removeTextNodes()
        }
            
        else
        {
            
            let results = hitTest.first?.node // Getting the node which got touched
            if results != nil {
                print("touched a node...")
                removeTextNodes()
                let altitude = results!.position.y as Float
                print(altitude)
                if altitude != 0.0{//a plane
                    var index = 0
                    while index<(terrainNode?.childNodes.count)!{
                        if (terrainNode?.childNodes[index])! == results!{
                            //print("Yeh hai wo node")
                            //print(index)
                            let text = SCNText(string: nodeDescription[index], extrusionDepth: 1)
                            let material = SCNMaterial()
                            material.diffuse.contents = UIColor.red
                            text.materials = [material]
                            let childTextNode = SCNNode(geometry: text)
                            childTextNode.scale = SCNVector3(x: 0.025, y: 0.025, z: 0.025)
                            if childTextNode.position.y < 500.0 {// for land moving vehicles
                                childTextNode.scale = SCNVector3(x: 0.012, y: 0.012, z: 0.012)
                            }
                            childTextNode.position.z = 0.25
                            if let scale = terrainNode?.childNodes[index].scale{
                                if  scale.x == 20.0 { //is the node that carries plane
                                    //display in a text field
                                }
                                else{
                                    terrainNode?.childNodes[index].addChildNode(childTextNode)
                                }
                            }
                        }
                        index+=1
                    }
                }
                //terrainNode?.index(ofAccessibilityElement: results! as SCNNode)
                
            }
            
            
        }
        
    }
    func setupSceneView(){
        self.view.addSubview(sceneView)
        sceneView.frame = self.view.bounds
        
        
        sceneView.allowsCameraControl = true
        sceneView.isPlaying = true
        
        cameraNode.camera = SCNCamera()
        cameraNode.position = SCNVector3(x: 0, y: 0, z: -1)
        sceneView.scene.rootNode.addChildNode(cameraNode)
        
        let lightNode = SCNNode()
        let light = SCNLight()
        light.type = .ambient
        light.intensity = 1000
        lightNode.light = light
        sceneView.scene.rootNode.addChildNode(lightNode)
    }
    func resizeImage(image: UIImage, targetSize: CGSize) -> UIImage {
        let size = image.size
        
        let widthRatio  = targetSize.width  / size.width
        let heightRatio = targetSize.height / size.height
        
        // Figure out what our orientation is, and use that to form the rectangle
        var newSize: CGSize
        if(widthRatio > heightRatio) {
            newSize = CGSize(width: size.width * heightRatio, height: size.height * heightRatio)
        } else {
            newSize = CGSize(width: size.width * widthRatio,  height: size.height * widthRatio)
        }
        
        // This is the rect that we've calculated out and this is what is actually used below
        let rect = CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height)
        
        // Actually do the resizing to the rect using the ImageContext stuff
        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        image.draw(in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage!
    }
    
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
    }
}
