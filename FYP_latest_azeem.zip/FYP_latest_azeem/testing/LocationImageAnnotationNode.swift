import Foundation

import UIKit
import SceneKit
import ARKit
import ARCL
import CoreLocation

public class LocationImageAnnotationNode: LocationAnnotationNode{
    
    // image and text that are displayed by the child nodes
    public var image: UIImage
    var index=0
    // child nodes
  //  public let imageAnnotationNode: AnnotationNode
    
    public init(location: CLLocation?, image: UIImage, ind: Int) {
        self.index=ind
        self.image = image
        
        // create the child node that holds the location's marker image
        let imagePlane = SCNPlane(width: image.size.width*10, height: image.size.height*10)
        imagePlane.firstMaterial!.diffuse.contents = image
        imagePlane.firstMaterial!.lightingModel = .constant
        
      //  imageAnnotationNode = AnnotationNode(view: nil, image: image)
      //  imageAnnotationNode.geometry = imagePlane
        // initializer ARCL's LocationNode
      
        super.init(location: location, image: image)
     
        
        //scaleRelativeToDistance = false
    //    self.scaleRelativeToDistance=false
    //    super.scaleRelativeToDistance=false
        
       //  apply a billboard constraint so the parent node, so it always faces the user
       // let billboardConstraint = SCNBillboardConstraint()
       // billboardConstraint.freeAxes = SCNBillboardAxis.Y
       // constraints = [billboardConstraint]
        
        // add the child nodes
       // addChildNode(imageAnnotationNode)
        // center text correctly around (x) and below (y) origin (SCNText's origins in in the
    }
    
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
